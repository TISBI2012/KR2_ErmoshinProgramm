﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kr2MixailDelaet.Pages
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void BtnVhod_Click(object sender, RoutedEventArgs e)
        {
            string login = TBLogin.Text;
            string password = TBPassword.Text;

            var loggetUser = App.DB.User.FirstOrDefault(x => x.Login == login && x.Password == password);
            if (loggetUser == null)
            {
                MessageBox.Show("Проль или логин не верные");
                return;
            }
            else
            {
                MessageBox.Show("Вы успешно авторизовались");
            }
            //App.LoggetUser == loggetUser;
            if(loggetUser.RoleId == 1)
            {
                NavigationService.Navigate(new SotrudnikPage());
            }
            if (loggetUser.RoleId == 4)
            {
                NavigationService.Navigate(new GlavaOtdelaPage());
            }
        }

        private void BtnRegistration_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
