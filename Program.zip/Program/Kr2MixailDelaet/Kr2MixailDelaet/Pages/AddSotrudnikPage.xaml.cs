﻿using Kr2MixailDelaet.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kr2MixailDelaet.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddSotrudnikPage.xaml
    /// </summary>
    public partial class AddSotrudnikPage : Page
    {
        public AddSotrudnikPage()
        {
            InitializeComponent();
        }

        private void BtnAddSotrudnik_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddSotrudnikPage());
        }

        private void BtnEditUser_Click(object sender, RoutedEventArgs e)
        {
            var selectedUser = DGUser.SelectedItem as User;
            if(selectedUser == null)
            {
                MessageBox.Show("Selected User");
            }
            
        }

        private void BtnRemoveUser_Click(object sender, RoutedEventArgs e)
        {
            var selectedUser = DGUser.SelectedItem as User;
            if (selectedUser == null)
            {
                MessageBox.Show("Selected User");
            }
            //NavigationService.Navigate(new AddSotrudnikPage(selectedUser));
            App.DB.User.Remove(selectedUser);
            App.DB.SaveChanges();
            DGUser.ItemsSource = App.DB.User.ToList();
            Refresh();
        }

        private void Refresh()
        {
            DGUser.ItemsSource = App.DB.User.ToList();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            Refresh();
        }
    }
}
